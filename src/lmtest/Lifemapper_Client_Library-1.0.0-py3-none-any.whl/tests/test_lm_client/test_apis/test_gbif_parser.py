"""Module containing tests for the gbif_parser service end-point
"""
