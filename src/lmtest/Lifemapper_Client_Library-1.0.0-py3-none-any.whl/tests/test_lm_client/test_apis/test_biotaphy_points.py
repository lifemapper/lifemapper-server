"""Module containing test functions for the biotaphy_points end-point
"""
