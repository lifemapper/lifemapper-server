"""Module containing tests for the open tree service end-point
"""
