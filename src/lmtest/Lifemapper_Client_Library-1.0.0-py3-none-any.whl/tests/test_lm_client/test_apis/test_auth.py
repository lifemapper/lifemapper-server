"""Module containing tests for the authentication service end-point
"""
