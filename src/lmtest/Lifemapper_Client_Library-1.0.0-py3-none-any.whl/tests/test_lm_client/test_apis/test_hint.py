"""Module containing tests for the hint service end-point
"""
