"""Module containing tests for the OGC service end-point
"""
