"""Module containing tests for the raw solr service end-point
"""
